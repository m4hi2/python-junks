from distutils.core import setup
setup (
  name         = 'nester',
  version      = '1.4.3',
  py_modules   = ['nester'],
  author       = 'Mahir Labib Chowdhury',
  author_email = 'optical.mahir@gmail.com',
  url          = 'http://www.rawposts.wordpress.com',
  description  = 'A simple printer of nested lists',
  )

