Use:
form print_endl import print_endl
print_endl(string)


Description: 
This actually prints something without invoking a new line. 
Equvalent to pritn(string, end='')