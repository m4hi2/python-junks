def print_endl(string):
  print(string, end='')
