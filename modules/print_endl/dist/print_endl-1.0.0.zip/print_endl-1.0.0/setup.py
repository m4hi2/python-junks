from distutils.core import setup
setup (
  name         = 'print_endl',
  version      = '1.0.0',
  py_modules   = ['print_endl'],
  author       = 'm4hi2',
  author_email = 'optical.mahir@gmail.coom',
  url          = '',
  description  = 'Just a function to print withot a new line',
  )

